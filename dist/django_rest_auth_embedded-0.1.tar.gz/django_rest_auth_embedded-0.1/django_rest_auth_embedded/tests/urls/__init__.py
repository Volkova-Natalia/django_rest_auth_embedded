from .base import BaseUrlsTestCase

from .registration import RegistrationUrlsTestCase
from .login import LoginUrlsTestCase
from .logout import LogoutUrlsTestCase
from .auth_info import AuthInfoUrlsTestCase
