from django.apps import AppConfig


class DjangoRestAuthEmbeddedConfig(AppConfig):
    name = 'django_rest_auth_embedded'
