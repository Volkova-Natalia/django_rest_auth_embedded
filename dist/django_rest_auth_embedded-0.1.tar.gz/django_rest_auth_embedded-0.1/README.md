# django_rest_auth_embedded
Packaged application to work with django embedded authentication.
